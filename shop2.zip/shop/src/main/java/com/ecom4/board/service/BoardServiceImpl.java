package com.ecom4.board.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.ecom4.board.dao.BoardDAO;
import com.ecom4.board.dto.BoardDTO;
import com.ecom4.common.dto.PageDTO;
import com.ecom4.common.dto.RowInterPage;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardDAO boardDAO;


	@Override
	public Map<String, Object> getArticles(BoardDTO dto, PageDTO pdto) {
		Map<String, Object> resultSet= new HashMap<String, Object>();
		if(pdto.getCurBlock()<=0) pdto.setCurBlock(1);
		if(pdto.getCurPage()<=0) pdto.setCurPage(1);
		//totalCnt도 받아오기
		int totalCnt = boardDAO.getTotalCnt();
        //페이지 계산해서 넣어주고
		int start = (pdto.getCurPage()-1)*RowInterPage.ROW_OF_PAGE + 1;
		int end = (pdto.getCurPage()*RowInterPage.ROW_OF_PAGE)>totalCnt ?
				   totalCnt : pdto.getCurPage()*RowInterPage.ROW_OF_PAGE;
		dto.setStart(start);
		dto.setEnd(end);
		int pgCnt = (totalCnt%RowInterPage.ROW_OF_PAGE==0) ?
		     totalCnt/RowInterPage.ROW_OF_PAGE : totalCnt/RowInterPage.ROW_OF_PAGE+1;
		//페이지 블럭
		int pgBlock = (pgCnt%RowInterPage.PAGE_OF_BLOCK==0) ?
				   pgCnt/RowInterPage.PAGE_OF_BLOCK : pgCnt/RowInterPage.PAGE_OF_BLOCK+1;
		int startPg = (pdto.getCurBlock()-1)*RowInterPage.PAGE_OF_BLOCK+1;
		int endPg = (pdto.getCurBlock()*RowInterPage.PAGE_OF_BLOCK > pgCnt) ?
					 pgCnt : pdto.getCurBlock()*RowInterPage.PAGE_OF_BLOCK;
		//리스트 받아오기
		List<BoardDTO> articles = boardDAO.getArticles(dto);
		//resultSet에 다 저장하기
		pdto.setPgCnt(pgCnt);
		pdto.setPgBlock(pgBlock);
		pdto.setStartPg(startPg);
		pdto.setEndPg(endPg);
		resultSet.put("totalCnt", totalCnt);
		resultSet.put("pdto", pdto);
		resultSet.put("articles", articles);
		
		return resultSet;
	}
	@Override
	public void writeAction(BoardDTO dto) {
		boardDAO.writeAction(dto);
	}
	@Override
	public int deleteArticle(BoardDTO dto) {
		return boardDAO.deleteArticle(dto);
	}
	@Override
	public BoardDTO getArticle(BoardDTO dto) {
		return boardDAO.getArticle(dto);
	}
	@Override
	public int updateArticle(BoardDTO dto) {
		return boardDAO.updateArticle(dto);
	}

}
