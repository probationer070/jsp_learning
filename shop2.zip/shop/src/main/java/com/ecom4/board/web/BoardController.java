package com.ecom4.board.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecom4.board.dto.BoardDTO;
import com.ecom4.board.service.BoardService;
import com.ecom4.common.dto.PageDTO;
import com.ecom4.common.dto.RowInterPage;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


@Controller
public class BoardController {
	private static final Logger logger= 
			LoggerFactory.getLogger(BoardController.class);

	@Autowired
	BoardService boardService ;
	
	@RequestMapping("/boardList")
	public String boardList(HttpServletRequest request,
			                HttpServletResponse response,
			                BoardDTO dto,
			                Model model,
			                PageDTO pdto) {
		Map<String, Object> resultSet
		 = boardService.getArticles(dto,pdto);
		
		model.addAttribute("articles", resultSet.get("articles"));
		model.addAttribute("totalCnt", resultSet.get("totalCnt"));
		model.addAttribute("pdto", resultSet.get("pdto"));
		model.addAttribute("pBlock", RowInterPage.PAGE_OF_BLOCK);
		model.addAttribute("contentsJsp", "board/BoardList");
		return "Main";
	}
	
	@RequestMapping(value = "writeForm")
	public String writeForm(HttpServletRequest request, 
				HttpServletResponse response, 
				BoardDTO dto, Model model, 
				PageDTO pdto) {
		model.addAttribute("article", dto);
		model.addAttribute("pdto", pdto);
		model.addAttribute("contentsJsp", "board/BoardWriteForm");
		
		return "Main";
	}
	

	@RequestMapping(value = "writeAction")
	public String writeAction(HttpServletRequest request, 
						HttpServletResponse response, 
						BoardDTO dto, Model model, 
						PageDTO pdto) {
		dto.setIp(request.getRemoteAddr());
		boardService.writeAction(dto);
		
		model.addAttribute("pdto", pdto);
		return "redirect:boardList";
	}
	
	@RequestMapping(value = "content")
	public String getArticle(HttpServletRequest request, HttpServletResponse response, BoardDTO dto, Model model, PageDTO pdto) {
		//service의 getArticle호출 해서 받은 article 저장 예정
		
		BoardDTO article = boardService.getArticle(dto);
		
		model.addAttribute("article", article);
		model.addAttribute("pdto", pdto);
		model.addAttribute("contentsJsp", "board/BoardContent");
		
		return "Main";
	}
	
	@RequestMapping(value = "updateForm")
	public String updateForm(HttpServletRequest request, HttpServletResponse response, BoardDTO dto, Model model, PageDTO pdto) {
		model.addAttribute("article", dto);
		model.addAttribute("pdto", pdto);
        model.addAttribute("contentsJsp", "board/BoardUpdateForm");
		
		return "Main";
	}
	
	@RequestMapping(value = "updateAction")
	public String updateAction(HttpServletRequest request, HttpServletResponse response, BoardDTO dto, Model model, PageDTO pdto) {
		dto.setIp(request.getRemoteAddr());
		String msg = null;
		
		int r = boardService.updateArticle(dto);
		
		if(r==0) {
			msg = "수정실패";
		}else if(r==1) {
			msg = "수정성공";
		}		
		model.addAttribute("msg", msg);
		model.addAttribute("pdto", pdto);
		model.addAttribute("url", "boardList?curPage="+pdto.getCurPage());
		
		return "MsgPage";
	}
	
	@RequestMapping(value = "deleteAction")
	public String deleteAction(HttpServletRequest request, HttpServletResponse response, BoardDTO dto, Model model, PageDTO pdto) {
		String msg = null;
		
		int r = boardService.deleteArticle(dto);
		
		if(r==0) {
			msg = "삭제실패";
		}else if(r==1) {
			msg = "삭제성공";
		}		
		model.addAttribute("msg", msg);
		model.addAttribute("pdto", pdto);
		model.addAttribute("url", "boardList?curPage="+pdto.getCurPage());
		
		return "MsgPage";
	}
}
