package com.ecom4.custom.service;

public interface CustomService {

	int test();

}
