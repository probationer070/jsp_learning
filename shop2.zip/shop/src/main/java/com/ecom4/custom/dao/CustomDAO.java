package com.ecom4.custom.dao;

import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CustomDAO {

	int test();

}
