package com.ecom4.custom.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ecom4.custom.dto.MemberDTO;
import com.ecom4.custom.service.CustomService;
import com.ecom4.member.service.MemberService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class CustomController {
  private static final Logger logger = LoggerFactory.getLogger(CustomController.class);
	
  @Autowired
  CustomService customService;
  
  @Autowired
  MemberService memberService;
    
  //주문에 대한 서비스
  
  @RequestMapping("/")
  public String  index(HttpServletRequest request) {
	    MemberDTO ssKey=null;
	    String page=null;
		HttpSession session = request.getSession();
		if(session.getAttribute("ssKey")!=null ) {
			ssKey = (MemberDTO) session.getAttribute("ssKey");
			if(ssKey.getM_role().equals("admin"))
				page="redirect:/admin/";
			else page="index";
		}
		else {
			page="index";
		}
	  return page;
  }
  
  @RequestMapping("/join")
  public String  join(HttpServletRequest request,
		              HttpServletResponse response,
		              Model model,
		              MemberDTO mdto) {
	  return "custom/MemberJoin";
  }
  @RequestMapping("/registerProc")
  public String  registerProc(HttpServletRequest request,
		  HttpServletResponse response,
		  Model model,
		  MemberDTO mdto) {
	  try {
		  memberService.memberJoin(mdto);
	} catch (Exception e) {
		 logger.error("에러:"+e.getMessage());
	}
	  
	  return "redirect:/";
  }
  
  @RequestMapping("/idCheck")
  @ResponseBody
  public int idCheck(HttpServletRequest request,
		  HttpServletResponse response,
		  Model model,
		  MemberDTO mdto) {
	  int cnt = 0;
	    if(mdto.getMem_id()!=null) {
	    	cnt = memberService.idCheck(mdto.getMem_id());
	    }
	  return cnt;
  }
  
  
  
  
}



