package com.ecom4.member.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.ecom4.custom.dto.MemberDTO;

@Mapper
public interface MemberDAO {

	int idCheck(String mem_id);

	int memberJoin(MemberDTO mdto);

	MemberDTO getMember(MemberDTO mdto);

	String searchId(MemberDTO mdto);

	int updatePasswd(MemberDTO mdto);

	int memberTot();

	List<MemberDTO> getMembers(MemberDTO mdto);

	int memUpProc(MemberDTO mdto);

	int memDelete(MemberDTO mdto);

}
