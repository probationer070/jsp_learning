package com.ecom4.member.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ecom4.custom.dto.MemberDTO;
import com.ecom4.member.service.MemberService;
import com.ecom4.wrapper.MemberWrapper;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class MemberController {
   private static final Logger logger = 
		   LoggerFactory.getLogger(MemberController.class);
	
	@Autowired
	MemberService memberService;
	
	@Autowired
	MemberWrapper memberWrapper;
	
	@RequestMapping("loginProc")
	public String loginProc(HttpServletRequest request,
			                HttpServletResponse response,
			                MemberDTO mdto,
			                Model model) {
		//세션 정보 (ssKey) - 회원정보
		HttpSession session = request.getSession();
		MemberDTO sdto = memberService.getMember(mdto);
		String url="/";
	    String msg;
		if(sdto!=null) {
		//회원 맞음
			if(sdto.getM_role().equals("admin")) {
				//관리자용 페이지로 url
				url="/admin/";
			}else {
				url="/";
			}
			MemberDTO ssKey = new MemberDTO();
			ssKey.setMem_id(sdto.getMem_id());
			ssKey.setM_passwd(sdto.getM_passwd());
			ssKey.setM_name(sdto.getM_name());
			ssKey.setM_role(sdto.getM_role());
		    msg =  sdto.getM_name()+"님 반갑습니다.!!";
			session.setAttribute("ssKey", ssKey);
		} else msg="아이디 또는 패스워드 맞지 않습니다.";
			
		model.addAttribute("msg",msg);
		model.addAttribute("url", url);
		return "MsgPage";
	}
	
	@RequestMapping("/logoutProc")
	public String logoutProc(HttpServletRequest request,
			HttpServletResponse response,
			MemberDTO mdto,
			Model model) {
		//세션 정보 (ssKey) - 회원정보
		HttpSession session = request.getSession();
         session.invalidate();
        return "redirect:/";
	}
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request,
			HttpServletResponse response,
			MemberDTO mdto,
			Model model) {
//		model.addAttribute("contentsJsp", "custom/Login");
		return "custom/Login";
	}
	@RequestMapping("/memSearch")
	public String memSearch(HttpServletRequest request,
			HttpServletResponse response,
			MemberDTO mdto,
			Model model) {
 //이름 전화 번호 받은 화면  ---id를 찾는 것이면 화면이 id 찾는 폼
 //아이디, 이름, 전호번호 받고  ---비번 새로 저장하는 폼
		return "custom/searchPage";
	}
	
	@RequestMapping("/memSearchProc")
	public String memSearchProc(HttpServletRequest request,
			HttpServletResponse response,
			MemberDTO mdto,
			Model model) {
	 //회원이 맞으면 비밀번호 새로 설정 페이지 
	 //회원정보가 맞지 않습니다.msg 회원가입으로 
		return "custom/Login";
	}
	
	@RequestMapping("/info")
	public String info(HttpServletRequest request,
			HttpServletResponse response,
			Model model) {
	   //session정보 갖고오기
		HttpSession session = request.getSession();
		MemberDTO custom = (MemberDTO) session.getAttribute("ssKey");
		//세션정보를 기준으로 회원 정보 가져오기
		String url=null;
		String msg=null;
		String page=null;
		if(custom !=null ) {
			MemberDTO mdto = memberService.getMember(custom);
			model.addAttribute("mdto", mdto);
			model.addAttribute("contentsJsp", "custom/MemberInfo");
	  	     page="Main";
	    }else {
	        msg = "로그인 먼저 필요합니다.";
	        url="/login";
	        model.addAttribute("msg", msg);
	        model.addAttribute("url", url);
	        page="MsgPage";
	  	   }
		session.setAttribute("ssKey", custom);
		return page;
	
	}
	@RequestMapping("/memUpForm")
	public String memUpForm(HttpServletRequest request,
			HttpServletResponse response,
			Model model) {
		//session정보 갖고오기
		HttpSession session = request.getSession();
		MemberDTO custom = (MemberDTO) session.getAttribute("ssKey");
		//세션정보를 기준으로 회원 정보 가져오기
		String url=null;
		String msg=null;
		String page=null;
		if(custom !=null ) {
			MemberDTO mdto = memberService.getMember(custom);
			model.addAttribute("mdto", mdto);
			model.addAttribute("contentsJsp", "custom/MemberUpForm");
			page="Main";
		}else {
			msg = "로그인 먼저 필요합니다.";
			url="/login";
			model.addAttribute("msg", msg);
			model.addAttribute("url", url);
			page="MsgPage";
		}
		session.setAttribute("ssKey", custom);
		return page;
		
	}
	
	@RequestMapping("/memUpProc")
	public String memUpProc(HttpServletRequest request,
			HttpServletResponse response,
			Model model, MemberDTO mdto ) {
		//session정보 갖고오기
		HttpSession session = request.getSession();
		MemberDTO custom = (MemberDTO) session.getAttribute("ssKey");
		//세션정보를 기준으로 회원 정보 가져오기
		String url=null;
		String msg=null;
		String page=null;
		if(custom !=null ) {
			 int r =memberService.memUpProc(mdto);
			if(r>0) {
				msg= "회원정보가 수정되었습니다.\\n 재로그인이 필요합니다.";
				session.invalidate();
			}
			else  {
				msg="수정되지 않았습니다.\\n 관리자에게 문의바랍니다.";
			}
			url = "/";
		}else {
			msg = "로그인 먼저 필요합니다.";
			url="/login";
		}
		page="MsgPage";
		model.addAttribute("msg", msg);
		model.addAttribute("url", url);
		return page;
	}
	@RequestMapping("/memdelete")
	public String memdelete(HttpServletRequest request,
			HttpServletResponse response,
			Model model, MemberDTO mdto ) {
		//session정보 갖고오기
		HttpSession session = request.getSession();
		MemberDTO custom = (MemberDTO) session.getAttribute("ssKey");
		//세션정보를 기준으로 회원 정보 가져오기
		String url=null;
		String msg=null;
		String page=null;
		if(custom !=null ) {
			int r =memberWrapper.memDelete(custom);
			  if(r>0) { 
				  msg= "회원이 탈퇴 처리 되었습니다."; 
				  session.invalidate(); 
				  }
			  else{
				  msg="탈퇴할 수 없습니다.\\n 관리자에게 문의바랍니다."; 
				  }
			url = "/";
		}else {
			msg = "로그인 먼저 필요합니다.";
			url="/login";
		}
		page="MsgPage";
		model.addAttribute("msg", msg);
		model.addAttribute("url", url);
		return page;
	}
	
	@RequestMapping("/searchProc")
	public String searchProc(HttpServletRequest request,
			HttpServletResponse response,
			MemberDTO mdto,
			Model model) {
		int r=0;
		String id=null;
		String msg=null;
		String url = "/";
	   if(mdto!=null) {
		   if(mdto.getMem_id()!=null) { //비밀번호 설정
			   r= memberService.updatePasswd(mdto);
			   if(r>0) {
				   msg="비밀번호가 변경되었습니다.";
			   }else { msg="비밀번호가 변경오류입니다.\\n 관리자에게 문의하세요";
   			         }
		   }else { //아이디 찾아서 리턴
			   id = memberService.searchId(mdto);
			   if(id!=null) msg="회원아이디: "+id;
			   else msg="회원정보가 없습니다.";
			   url="memSearch";
		   }
	   }
		model.addAttribute("msg", msg);
		model.addAttribute("url", url);
		return "MsgPage";
	}
	
	@RequestMapping("/pwCheck")
	public String pwCheck(HttpServletRequest request,
			Model model) {
		return "custom/PwCheck";
	}
	
	
	
}






