package com.ecom4.member.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecom4.common.dto.PageDTO;
import com.ecom4.custom.dto.MemberDTO;
import com.ecom4.member.dao.MemberDAO;

@Service
public class MemberServiceImpl implements MemberService {
   @Autowired
   MemberDAO memberDao;
	
	@Override
	public int idCheck(String id) {
		return memberDao.idCheck(id);
	}

	@Override
	public int memberJoin(MemberDTO mdto) throws Exception {
		return memberDao.memberJoin(mdto);
	}

	@Override
	public MemberDTO getMember(MemberDTO mdto) {
		return memberDao.getMember(mdto);
	}

	@Override
	public String searchId(MemberDTO mdto) {
		return memberDao.searchId(mdto);
	}

	@Override
	public int updatePasswd(MemberDTO mdto) {
		return memberDao.updatePasswd(mdto);
	}

	@Override
	public Map<String, Object> getMembers(MemberDTO mdto, PageDTO pdto) {
		Map<String, Object> reSet= new HashMap<String, Object>();
		//전체 카운트 갖고오기
		//전체 회원리스 갖고오기
		int memberTot = memberDao.memberTot();
		List<MemberDTO> members = memberDao.getMembers(mdto);
		//저장하기(reSet)
		reSet.put("memberTot", memberTot);
		reSet.put("members", members);
		return reSet;
	}

	@Override
	public int memUpProc(MemberDTO mdto) {
		return memberDao.memUpProc(mdto);
	}

	@Override
	public int memDelete(MemberDTO mdto) {
		return memberDao.memDelete(mdto);
	}

}






