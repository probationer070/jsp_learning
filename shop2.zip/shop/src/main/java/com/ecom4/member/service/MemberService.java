package com.ecom4.member.service;

import java.util.Map;

import com.ecom4.common.dto.PageDTO;
import com.ecom4.custom.dto.MemberDTO;

public interface MemberService {
	int  idCheck(String id);

	int memberJoin(MemberDTO mdto) throws Exception;

	MemberDTO getMember(MemberDTO mdto);

	String searchId(MemberDTO mdto);

	int updatePasswd(MemberDTO mdto);

	Map<String, Object> getMembers(MemberDTO mdto, PageDTO pdto);

	int memUpProc(MemberDTO mdto);

	int memDelete(MemberDTO mdto);
}
