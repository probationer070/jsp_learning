package com.ecom4.product.web;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.ecom4.common.dto.PageDTO;
import com.ecom4.custom.dto.MemberDTO;
import com.ecom4.product.dto.ProductDTO;
import com.ecom4.product.service.ProductService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
public class ProductController {

	private static final Logger logger 
	  = LoggerFactory.getLogger(ProductController.class) ;
	
	@Autowired
	ProductService productService;
	//실제로 파일이 저장되는 파일서버 경로 설정한 값을 가져온것
	@Value("${resources.location}")
	String resourcesLocation;
	
	@RequestMapping("/productMgt")
	public String productMgr(HttpServletRequest request,
							 HttpServletResponse respose,
							 Model model,
							 ProductDTO pdto,
							 PageDTO pageDto) {
		String page=null;
		MemberDTO ssKey =null;
		HttpSession session = request.getSession();
	    if(session.getAttribute("ssKey")!=null ) {
    	 ssKey = (MemberDTO) session.getAttribute("ssKey");
    	  if(ssKey.getM_role().equals("admin"))
	        page="admin/ProductMgt";
    	  else page="redirect:/";
	    }
	    else {
	    	page="redirect:/";
	    }
		//모든 상품 리스트를 갖고 오기 --getProductList
		Map<String, Object> reSet =  
		productService.getProductList(pageDto);
		model.addAttribute("pcnt", reSet.get("pcnt"));
		//해당 리스트를 저장("productList",)
		model.addAttribute("pList", reSet.get("pList"));
	    session.setAttribute("ssKey", ssKey);
		return page;
	}
	
	@RequestMapping("/productInForm")
	public String productInForm(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto) {
		String page=null;
		MemberDTO ssKey =null;
		HttpSession session = request.getSession();
		if(session.getAttribute("ssKey")!=null ) {
			ssKey = (MemberDTO) session.getAttribute("ssKey");
			if(ssKey.getM_role().equals("admin"))
				page="admin/ProductInForm";
			else page="redirect:/";
		}
		else {
			page="redirect:/";
		}
		//모든 상품 리스트를 갖고 오기 --getProductList
		session.setAttribute("ssKey", ssKey);
		return page;
	}
	
	@RequestMapping("/productUpForm")
	public String productUpForm(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto) {
		String page=null;
		MemberDTO ssKey =null;
	    ProductDTO pvo=null;
		HttpSession session = request.getSession();
		if(session.getAttribute("ssKey")!=null ) {
			ssKey = (MemberDTO) session.getAttribute("ssKey");
			if(ssKey.getM_role().equals("admin")) {
			  pvo= productService.getProduct(pdto.getP_no());
			  page="admin/ProductUpForm";
				}
			else page="redirect:/";
		}
		else {
			page="redirect:/";
		}
		//모든 상품 리스트를 갖고 오기 --getProductList
		model.addAttribute("pdto", pvo);
		session.setAttribute("ssKey", ssKey);
		return page;
	}
	
	
	@RequestMapping("/productMgtProc")
	public String productMgtProc(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto, 
			@RequestParam("image2") MultipartFile file) {
		MemberDTO ssKey =null;
		String url = null;
		String msg = null;
		int r;
		HttpSession session = request.getSession();
		if(session.getAttribute("ssKey")!=null ) {
		 ssKey = (MemberDTO) session.getAttribute("ssKey");
		 if(ssKey.getM_role().equals("admin")) {
			//실제로 작업(flag따라서 insert와 update)
		  String flag = request.getParameter("flag");
		  if(flag.equals("insert")) {
			  //업로드 경로 저장
			  pdto.setPath(resourcesLocation);
			  r = productService.insertProduct(pdto, file);
			  if(r>0) {
				  msg = "상품등록성공";
			  }else {
				  msg = "상품등록실패";
			  }
			  url = "productMgt";
		   }else if(flag.equals("update")) {
			   pdto.setPath(resourcesLocation);
			   r = productService.updateProduct(pdto, file);
			   if(r>0) {
					  msg = "상품수정성공";
				  }else {
					  msg = "상품수정실패";
				  }
				  url = "productMgt";
		   }
		 }else {
			 url="redirect:/";
			 msg="잘못된 경로 접근입니다.";
		 }
		}
		model.addAttribute("msg", msg);
		model.addAttribute("url", url);
		session.setAttribute("ssKey", ssKey);
		return "MsgPage";
	}
	
	@RequestMapping("/productList")
	public String productList(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto) {
		Map<String, Object> reSet 
		  = productService.getProductList(pageDto);
		
		model.addAttribute("pcnt", reSet.get("pcnt"));
		model.addAttribute("pList", reSet.get("pList"));
		model.addAttribute("contentsJsp", "custom/ProductList");
		return "/Main";
	}
	
	@RequestMapping("/productDetail")
	public String productDetail(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto) {
		
		String contentsJsp= null;
		String page = null;
		HttpSession session = request.getSession();
	    MemberDTO mdto =(MemberDTO) session.getAttribute("ssKey");
	  	if(mdto !=null ) {
	  		if(mdto.getM_role().equals("mem")) {//고객
	  			contentsJsp = "custom/ProductDetail";
	  			page = "/Main";
	  		}else if(mdto.getM_role().equals("admin")) {
	  			contentsJsp = "./ProductDetail";
	  			page="admin/Main";
	  		}
	  	}else {
	  		contentsJsp = "custom/ProductDetail";
  			page = "/Main";
	  	}
		ProductDTO product  
		= productService.getProduct(pdto.getP_no());
		
		model.addAttribute("product", product);
		model.addAttribute("contentsJsp", contentsJsp);
		session.setAttribute("ssKey", mdto);
		return page;
	}
	
	@RequestMapping("orderCntOfProduct")
	@ResponseBody
	public int orderCntOfProduct(HttpServletRequest request) {
		int pno =Integer.parseInt(request.getParameter("p_no"));
		logger.info("==>"+pno);
		return productService.orderCntOfProduct(pno);
	}
	
	@RequestMapping("productDel")
	public String productDel(HttpServletRequest request,
			HttpServletResponse respose,
			Model model,
			ProductDTO pdto,
			PageDTO pageDto) {
		String url = null;
		String msg = null;
		HttpSession session = request.getSession();
	    MemberDTO mdto =(MemberDTO) session.getAttribute("ssKey");
	  	if(mdto !=null ) {
	  		if(mdto.getM_role().equals("mem")) {//고객
	  			url="/";
	  		}else if(mdto.getM_role().equals("admin")) {
	  			logger.info("pdto");
	  			int r = productService.productDel(pdto);
	  			if(r>0) msg= pdto.getP_name()+"이/가 삭제되었습니다."; 
	  			else msg= pdto.getP_name()+"이/가 삭제되지 않았습니다.";
	  			url = "productMgt";
	  		}
	  	}else {
	  		msg="로그인이 필요합니다.";
	  		url ="/login";
	  	}
	  	model.addAttribute("msg", msg);
	  	model.addAttribute("url", url);
		session.setAttribute("ssKey", mdto);
		return "MsgPage"; 
	}
	
}




