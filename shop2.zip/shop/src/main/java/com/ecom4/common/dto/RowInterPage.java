package com.ecom4.common.dto;
public interface RowInterPage {
	public static final int ROW_OF_PAGE = 4;
	public static final int PAGE_OF_BLOCK = 2;
}