package com.ecom4.notice.service;

import java.util.Map;

import com.ecom4.common.dto.PageDTO;
import com.ecom4.notice.dto.NoticeDTO;

public interface NoticeService {

	Map<String, Object> getNoticies(NoticeDTO ndto, PageDTO pdto);

	void generateNotice(NoticeDTO ndto);

	NoticeDTO getNotice(NoticeDTO ndto);

	int deleteProc(NoticeDTO ndto);

	int updateProc(NoticeDTO ndto);

}
