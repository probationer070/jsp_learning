package ch03;

import java.util.Scanner;

public class SwitchDemo02 {

	public static void main(String[] args) {
		try (
			Scanner sc = new Scanner(System.in)) {
			System.out.println("What is your Score : ");
			int score = sc.nextInt();
			
			String grade = "";
			
			if(score > 100 || score < 0) {
				System.out.println("[ Error occur : exceeding value Founded in textarea ]");
				System.exit(0);
			} else {
//				if(score>=95) grade="A+";
//				else if (score>=90) grade="A";
//				else if (score>=85) grade="B+";
//				else if (score>=80) grade="B";
//				else if (score>=75) grade="C+";
//				else if (score>=70) grade="C";
//				else if (score>=65) grade="D+";
//				else if (score>=60) grade="D";
//				else grade="F";
				
				int d = score / 10;
				switch(d) {
				case 10: 
					System.out.println("Congratulation 100");
					break;
				case 9:
					if (d % 5 == 0) {
						grade = "A+"; 
					} else {
						grade = "A"; 
					}
					break;
				case 8:
					if (d % 5 == 0) {
						grade = "B+"; 
					} else {
						grade = "B"; 
					}
					break;
				case 7:
					if (d % 5 == 0) {
						grade = "C+"; 
					} else {
						grade = "C"; 
					}
					break;
				case 6:
					if (d % 5 == 0) {
						grade = "D+";
					} else {
						grade = "D";
					}
					break;
				default:
				}
				
				
				System.out.println("Your GRADE : "+grade);
			}
		}
		
	}
}
