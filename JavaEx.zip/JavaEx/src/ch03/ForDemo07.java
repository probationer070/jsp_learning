package ch03;

import java.util.Scanner;

public class ForDemo07 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int num = sc.nextInt();
		/*
		 * for (int i=1; i<10; i++) { System.out.print("*"); }
		 */
		
		//----------------------------------------
		// 반삼각형 좌측
		
//		for (int i=1; i<10; i++) {
//			for (int j=1; j<10-i; j++) {
//				System.out.print(" ");
//			}
//			
//			for (int j=1; j<i; j++) {
//				System.out.print("*");
//			}
//			System.out.println("\n");
//		}
		
		//----------------------------------------
		// 역반삼각형
		
		
		
//		for (int i=1; i<10; i++) {
//			for (int j=1; j<10-i; j++) {
//				System.out.print("*");
//			}
//			
//			for (int j=1; j<i; j++) {
//				System.out.print(" ");
//			}
//			System.out.println("\n");
//		}
		
		//----------------------------------------
		// 반삼각형 우측
		
//		for (int i=1; i<num; i++) {
//			for (int j=1; j<i; j++) {
//				System.out.print("*");
//			}
//			System.out.println("\n");
//		}
		
		//-----------------------------------------
		// 다이아 모양
		for (int i=1; i<=num; i++) {
            for (int j=0; j<num-i; j++) {
                System.out.print(" ");
            }
            
            for (int j=0; j<2*i-1; j++) {
                System.out.print("*");
            }
            System.out.println("\n");
        }
        
        for (int i=num-1; i>0; i--) {
            for (int j=0; j<num-i; j++) {
                System.out.print(" ");
            }
            
            for (int j=0; j<2*i-1; j++) {
                System.out.print("*");
            }
            System.out.println("\n");
        }
		sc.close();
	}
}
