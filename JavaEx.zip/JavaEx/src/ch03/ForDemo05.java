package ch03;

public class ForDemo05 {

	public static void main(String[] args) {
		for (int i=1; i<5; i++) {		// 1 ~ 4 까지 출력
			System.out.println(i);	// 줄바꿈 없이
		}
	}
}
