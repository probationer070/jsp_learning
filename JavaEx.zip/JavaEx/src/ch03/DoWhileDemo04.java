package ch03;


public class DoWhileDemo04 {

	public static void main(String[] args) {
		int row = 2;
		do {
			int column = 1;
			System.out.printf("--------%d--------\n", row);
			do {
				System.out.printf("%3d * %3d = %4d\n", row, column, row*column);
				column++;
				
				
			} while (column < 10);
			System.out.println();
			row++;
		} while (row < 10);
	}
}
