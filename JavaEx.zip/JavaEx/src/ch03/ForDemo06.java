package ch03;

public class ForDemo06 {

	public static void main(String[] args) {
		for (int i=1; i<10; i+=3) {
			System.out.printf("------%d단------", i);
			System.out.printf(" ------%d단------", i+1);
			System.out.printf(" ------%d단------\n", i+2);
			for (int j=1; j<10; j++) {
				System.out.printf("%3d *%3d =%4d", i, j, i*j);
				System.out.printf("%3d *%3d =%4d", i+1, j, (i+1)*j);
				System.out.printf("%3d *%3d =%4d\n", i+2, j, (i+2)*j);
			}
		}
	}
}
