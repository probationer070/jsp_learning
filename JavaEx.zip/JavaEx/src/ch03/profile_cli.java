package ch03;
import java.util.Scanner;

public class profile_cli {
	void login() {
			Scanner scan = new Scanner(System.in);
			
			System.out.println("[+] id : ");
			String uname = scan.nextLine();
			
			System.out.println("[+] Passsword : ");
			String upwd = scan.nextLine();
			
			if (uname.equals("park") && upwd.equals("0000")) {
				System.out.println("Access!! -> login complete");
				System.out.println("[ 1 : My Profile ]");
				System.out.println("[ x : back to the MENU ]");
			}

			else {
				System.out.println("Access Denied -> X");
			}
			scan.close();
		}
	
	void check() {
		int cnt = 10;
		String msg = cnt > 0 ? "new msg arrived" : "None";
		System.out.println(msg);
	}
	
	void profile() {
		Scanner scan = new Scanner(System.in);
		String input_num = scan.nextLine();
		
		if (input_num.equals("1")) {
			System.out.println("profile : Park jaehwan");
			System.out.println("birth : 2002 / 02 / 22 ");
			System.out.println("age : 22");
			System.out.println("email address : blabla1234@gxxx.com");
			System.out.println("carerr : student");
			System.out.println("where : GyeongGi-Dou");
			System.out.println("\n[ x : back to the MENU ]");
		} else {
			System.out.println("exit");
		}
		scan.close();
	}

	
	
	public static void main(String[] args) {
		profile_cli con = new profile_cli();
		
		while(true) {
			System.out.println("Choose the menu ==> \n[ 1. login ]\n[ 2. Messages ]\n[ x. Exit ]");
			Scanner scan = new Scanner(System.in);
			String sel = scan.next();
			
			switch(sel) {
			case "1": con.login();con.profile();continue;
			case "2": con.check();break;
			case "x": System.exit(0);
			default: System.out.println("Wrong input");
			}
			scan.close();
		}
	}
}
