package ch03;

/*import java.util.Scanner;*/

public class ForDemo03 {

	public static void main(String[] args) {
		// 짝수 or 홀수의 합
		/*
		 * System.out.println("only 1 ~ 9, number :"); Scanner sc = new
		 * Scanner(System.in); int N = sc.nextInt();
		 */
		
		for (int i=1; i<=9; i++) {
			for (int j=1; j<=9; j++) {
				System.out.printf("%d단 %3d * %3d = %3d\n", i, i, j, i*j);
			}
		}
	}
}
