package ch03;

import java.util.Scanner;
public class NestedIfDemo01 {

	public static void main(String[] args) {
          //입력을 받아서 90점이상인 사람 중 96점이상이면 A+ 그렇지 않으면 A0
		  //90이상이 아니면 다음기회에.
		Scanner in = new Scanner(System.in);
	     System.out.print("당신의 점수는: ");
	     int score =  in.nextInt();
	     String grade = "";
	     if(score>=90) {
	    	 if(score>=96) {
	    		 grade ="A+";
	    	 }else {
	    		 grade="A0";
	    	 }
	       System.out.println("당신의 학점은 "+grade+"입니다.");	 
	     }else {
	    	 System.out.println("다음 기회에");
	     }
			 in.close();
		
	}

}
