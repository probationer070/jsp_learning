package ch03;
import java.util.Scanner;

public class IfElseDemo04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println(" Number Need : ");
		
		int score = sc.nextInt();
		// String grade = "";
		
		if (score % 2 == 0) {
			System.out.println("Insert Number : 짝수");
		} else {
			System.out.println("Insert Number : 홀수");
		}
		sc.close();
	}
}
