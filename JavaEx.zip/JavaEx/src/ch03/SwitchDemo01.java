package ch03;

public class SwitchDemo01 {

	public static void main(String[] args) {
		String s = "Strawberry";
		
		switch (s) {
		case "apple":
			System.out.println("apple");
			break;
		case "grape":
			System.out.println("grape");
			break;
		case "Strawberry":
			System.out.println("Strawberry");
			break;
		default:
			System.out.println("\\W/");
		}
		
		
		// 위에 코드와 동일한 내용
		if(s=="apple") {
			System.out.println("apple");
		} else if (s=="grape") {
			System.out.println("grape");
		} else if (s=="Strawberry") {
			System.out.println("Strawberry");
		} else {
			System.out.println("\\W/");
		}
	}
}
