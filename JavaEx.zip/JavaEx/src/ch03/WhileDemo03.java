package ch03;

import java.util.Scanner;

public class WhileDemo03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Write sentence : ");
		String line = sc.nextLine();
		int i = 0;
		sc.close();
		while(i < 5) {
			System.out.println(line);
			i++;
		}

	}

}
