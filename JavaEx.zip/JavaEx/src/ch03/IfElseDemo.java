package ch03;

import java.util.Scanner;

public class IfElseDemo {

       public static void main(String[] args) {
              Scanner in = new Scanner(System.in);
              System.out.print("숫자를 입력하시오: ");
              int n = in.nextInt();

              if (n % 2 == 0) {
                     System.out.println("짝수!");
              } else
                     System.out.println("홀수!");

              System.out.println("done");
              in.close();
       }      

}
