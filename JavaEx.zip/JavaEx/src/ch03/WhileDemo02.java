package ch03;

import java.util.Scanner;

public class WhileDemo02 {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		System.out.println("odd counter : ");
		int num = sc.nextInt();
		int i = 1;
		
		while(i <= num) {
			if (i % 2 == 0) System.out.println(i);
			i++;
		}
		sc.close();
	}

}
