package ch03;
import java.util.Scanner;

public class IfElseIfDemo03_1 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println(" Number Need : ");
		
		int score = sc.nextInt();
		String grade = "";
		
		if(score >= 90) {
			grade = "A";
			if(score >= 96) {
				grade = "A+";
			} else {
				grade = "A0";
			}
		} else {
			grade = "실격";
		}
		sc.close();
		System.out.println(grade);
	}
}
