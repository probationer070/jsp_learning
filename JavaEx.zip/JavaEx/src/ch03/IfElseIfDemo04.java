package ch03;
import java.util.Scanner;

public class IfElseIfDemo04 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println(" typing your score : ");
		
		int score = sc.nextInt();
		String grade = "";
		
		if(score > 100) {
			System.out.println("[ Error occur : exceeding value Founded in textarea ]");
			System.exit(0);
		} else if (score >= 90) { grade = "A"; } 
		  else if (score >= 80) { grade = "B"; } 
		  else if (score >= 70) { grade = "C"; } 
		  else if (score >= 60) { grade = "D"; } 
		  else if (score >= 0) { grade = "F"; }
		  else grade = "Error";
		  
		sc.close();
		System.out.println(grade);
	}
}
