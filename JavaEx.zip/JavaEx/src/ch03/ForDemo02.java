package ch03;

import java.util.Scanner;

public class ForDemo02 {

	public static void main(String[] args) {
		int sum = 0;
		for (int i=1; i <= 100; i++) {
			sum+=i;
		}
	
		
		System.out.println(sum);
		// 짝수 or 홀수의 합
		System.out.println("시그마  n :");
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		
		int sum2=0;
		for (int i=1; i<=N; i+=2) {
				sum2 += i;
		}
		System.out.println(sum2);
		sc.close();
	}
}
