package ch03;

import java.util.Scanner;

public class WhileDemo04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Write sentence : ");
		
		int sum = 0;
		int num = 0;
		while((num = sc.nextInt()) != -1) {	
			for (int i=0; i<= num; i++) {
				sum += i;
			}
			System.out.println(sum);
		}

		sc.close();
	}
}
