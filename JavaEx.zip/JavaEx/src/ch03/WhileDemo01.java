package ch03;

import java.util.Scanner;

public class WhileDemo01 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("SUM 1 ~ N : ");
		int N = sc.nextInt();
		int i = 1;
		int sum = 0;
		
		while(i <= N) {
			sum += i;
			i++;
		}
		
		int sum2 = 0;
		if (N % 2 == 0) {
			sum2 = (N+1) * (N/2);
		} else {
			sum2 = ((N+1) * ((N-1)/2)) + (N/2 + 1/2);
		}
		
		sc.close();
		System.out.println(sum2);
		System.out.println(sum);
	}

}
