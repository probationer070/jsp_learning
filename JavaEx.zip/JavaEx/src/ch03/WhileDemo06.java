package ch03;


public class WhileDemo06 {

	public static void main(String[] args) {
		int i =1;
		int j =1;
		
		do {
			System.out.printf("------%d------\n", i);
			i++;	
			j=1; // j값 초기화
			while (j<10) {	// j값 1 ~ 9까지 반복
				System.out.printf("%3d *%3d = %3d\n", i, j, i * j);
				j++;
			}
		} while (i<9); {	// i값 1~10 반복
			
		}
	}
}
