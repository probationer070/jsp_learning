package ch03;

public class ContinueDemo01 {

	public static void main(String[] args) {
//		for (int i=0; i<300; i++) {
//			if (i % 3 == 0) continue;
//			System.out.println(i);
//		}
//		
		int j=0;
		while(j<90) {
			System.out.println(j);
			j++;
			if (j % 4 == 0) continue;
		}
		
		System.out.println("-----------------");
		for(int l=0; l <= 900; l++) {
			if (l % 4 == 0) continue;
			System.out.println(l);
		}
	}
}
