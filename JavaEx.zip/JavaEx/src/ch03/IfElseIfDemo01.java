package ch03;

import java.util.Scanner;

public class IfElseIfDemo01 {

	public static void main(String[] args) {
       Scanner in = new Scanner(System.in);
       System.out.print("주민번호 뒷자리에서 첫번째 번호를 입력하시오: ");
       int g = in.nextInt();
       if(g==1) {
    	   System.out.println("당신은 남성이군요");
       }else if(g==2) {
    	   System.out.println("당신은 여성이군요");
       }else if(g==3) {
    	   System.out.println("당신은 남성이군요");
       }else if(g==4) {
    	   System.out.println("당신은 여성이군요");
       }else {
    	   System.out.println("헐! 당신은 뭐지?");
       }
       in.close();
  	}

}
