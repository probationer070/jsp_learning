package ch03;


public class WhileDemo05 {

	public static void main(String[] args) {
		int i =1;
		while (i<5) {
			System.out.println(i);
			i++;
		}
	}
}
