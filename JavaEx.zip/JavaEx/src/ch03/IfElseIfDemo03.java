package ch03;
import java.util.Scanner;

public class IfElseIfDemo03 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println(" typing your score : ");
		
		int score = sc.nextInt();
		String grade = "";
		
		if(score > 100 || score < 0) {
			System.out.println("[ Error occur : exceeding value Founded in textarea ]");
			System.exit(0);
		}
		
		if(score >= 90) {
			grade = "A";
			if(score >= 96) {
				grade = "A+";
			} else {
				grade = "A0";
			}
		} else if (score >= 80) {
			grade = "B";
			if (score >= 86) {
				grade = "B+";
			} else {
				grade = "B0";
			}
		} else if (score >= 70) {
			grade = "C";
			if (score >= 76) {
				grade = "C+";
			} else {
				grade = "C0";
			}
		} else if (score >= 60) {
			grade = "D";
			if (score >= 66) {
				grade = "D+";
			} else {
				grade = "D0";
			}
		} else {
			grade = "F";
		}
		sc.close();
		System.out.println(grade);
	}
}
