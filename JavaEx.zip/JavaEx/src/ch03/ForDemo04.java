package ch03;

public class ForDemo04 {

	public static void main(String[] args) {
		int i = 0;
		
		do { // 조건에 맞지 않아도 한 번은 실행.
			System.out.println(i);
			i++;
		} while(i<10);
		
		int j=0;
		
		while(i<10) { // 조건이 거짓이면 바로 실행 안 됨.
			System.out.println(j);
			j++;
		}
		
		int l=0;
		while(true) {
			l++;
			System.out.println(l);
			if (l==111) break;
		}
	}
}
