package ch03;


public class DoWhileDemo03 {

	public static void main(String[] args) {
		int i =1;
		do {
			i++;
		} while (i < 5);
		System.out.println("do~while 문 실행 후 : "+i);
		
		
		i=1;
		while (i < 5) {
			i++;
		}
		System.out.println("while 문 실행 후 : "+i);
	}
	
}
