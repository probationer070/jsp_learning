package ch03;

public class IfElseDemo03 {

	public static void main(String[] args) {
		
		int a = 3;
		
		if (a % 2 == 0) {
			System.out.println("짝수");
		} else {
			System.out.println("홀수");
		}
	}
}
