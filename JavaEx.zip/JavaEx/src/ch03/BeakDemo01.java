package ch03;

public class BeakDemo01 {

	public static void main(String[] args) {
		int i =0;
		while (i<=1000) {
			System.out.println(i);
			i++;
			if (i == 893) break;
		}
		
		for (int j=0; j<=1000; j++) {
			System.out.println(j);
			if (j == 893) break;
		}
	}
}
