package ch11.sec01.exam05;

public class Car {

}
