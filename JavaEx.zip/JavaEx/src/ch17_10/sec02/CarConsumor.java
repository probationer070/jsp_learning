package ch17_10.sec02;

public interface CarConsumor {
  void apply(Car car);
}
