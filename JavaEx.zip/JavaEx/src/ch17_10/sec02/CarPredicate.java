package ch17_10.sec02;

public interface CarPredicate {
  boolean test(Car car);
}

