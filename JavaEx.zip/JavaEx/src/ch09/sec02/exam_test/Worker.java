package ch09.sec02.exam_test;

public class Worker {
	public void start() {
		System.out.println("REST~");
	}
}
