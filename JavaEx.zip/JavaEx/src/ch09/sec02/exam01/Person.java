package ch09.sec02.exam01;

public class Person {
	void wake() {
		System.out.println("기상");
	}
}
