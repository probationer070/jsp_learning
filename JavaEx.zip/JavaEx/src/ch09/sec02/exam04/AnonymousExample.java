package ch09.sec02.exam04;

public class AnonymousExample {
	public static void main(String[] args) {
		Anonymous anony = new Anonymous();
		anony.method(1, 1);
	}
}
