package ch14.sec03;

import java.io.IOException;

public class ProductStorageExample {
    public static void main(String[] args) throws IOException {
        ProductStorage pStorage = new ProductStorage();
        pStorage.showMenu();
    }
}
