package ch08.sec02.exam02;

public interface Vehicle {
	public void run();
}
