package ch08.sec02.exam02;

public class Taxi implements Vehicle{
	public void run() {
		System.out.println("택시가 달립니다.");
	}
}