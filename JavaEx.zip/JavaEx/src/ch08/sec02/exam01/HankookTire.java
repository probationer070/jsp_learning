package ch08.sec02.exam01;

public class HankookTire implements Tire {
	public void roll() {
		System.out.println("HankookTire가 굴러갑니다");
	}
}
