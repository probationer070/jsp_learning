package ch08.sec02.exam01;

public class KumhoTire implements Tire {
	public void roll() {
		System.out.println("KumhoTire가 굴러갑니다");
	}
}
