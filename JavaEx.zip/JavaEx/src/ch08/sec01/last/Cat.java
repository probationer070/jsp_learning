package ch08.sec01.last;

public class Cat implements Soundable {
	public String sound() {
		return "Meow";
	}
}
