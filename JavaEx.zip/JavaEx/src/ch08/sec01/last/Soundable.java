package ch08.sec01.last;

public interface Soundable {
	String sound();
}
