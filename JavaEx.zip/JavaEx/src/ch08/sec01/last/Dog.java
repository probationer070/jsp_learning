package ch08.sec01.last;

public class Dog implements Soundable {
	public String sound() {
		return "Bark";
	}
}
