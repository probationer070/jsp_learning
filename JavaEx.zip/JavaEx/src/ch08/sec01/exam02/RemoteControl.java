package ch08.sec01.exam02;

public class RemoteControl {

}
