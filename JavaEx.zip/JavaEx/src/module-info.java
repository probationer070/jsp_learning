/**
 * 
 */
/**
 * 
 */
module JavaEx {
	requires java.desktop;
	requires java.sql;
}