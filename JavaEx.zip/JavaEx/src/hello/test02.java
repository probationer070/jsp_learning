package hello;

import java.util.Scanner;

public class test02 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char queue[] = new char[5];
        int rear = 0;
        
        char carName = 'A'; // ""는 char형을 받지 못함.
        int select = 9;
        
        
        while (select != 3) {
        	System.out.println("\n <1> car insert <2> car delete <3> exit :");
        	select = sc.nextInt();
        	
        	switch(select) {
        	case 1:
        		if (rear >= 5) {
        			System.out.println("Cannot Insert! hard traffic");
        		} else {
        			queue[rear] = carName++;
        			rear++;
        		}
        		System.out.println("Current CAR ==> ");
        		for (int i=0; i<5; i++) {
        			System.out.printf("%c", queue[i]);
        		}
        		break;
        		
        	case 2:
        		if (rear <= 0) {
        			System.out.println("Empty space\n");
        		} else {
        			for (int i=0; i<4;i++) {
        				queue[i] = queue[i+1];
        				rear--;
        			}
        		}
        		System.out.println("Current CAR ==> ");
        		for (int i=0; i<5; i++) {
        			System.out.printf("%c", queue[i]);
        		}
        		break;
        		
        		
        	case 3:
        		System.out.println("Current CAR ==> ");
        		for (int i=0; i<5; i++) {
        			System.out.printf("%c", queue[i]);
        		}
        		System.out.println("Program shutdown");
        		System.exit(0);
        		break;
        		
        	default:
        		System.out.println("Wrong Input detected! Try again");
        	}
        }
				sc.close();
    }
}