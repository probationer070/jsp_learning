package hello;

import java.util.Scanner;

public class test01 {
    public static void main(String[] args) {
        @SuppressWarnings("resource")
        var sc = new Scanner(System.in);
        int hab=0, gop=1;
        int arr[] = new int[4];
        int i = 0;
         
        for (i=0; i < 4; i++){
            System.out.println((i+1)+"st num : ");
            arr[i] = sc.nextInt();
        }



        i = 0;
        while(i < 4) {
            hab += arr[i];
            gop *= arr[i];
            i++;
        }
        sc.close();
        System.out.println(hab);
        System.out.println(gop);
    }
}