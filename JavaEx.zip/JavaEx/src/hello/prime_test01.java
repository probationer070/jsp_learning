package hello;

import java.util.Scanner;

public class prime_test01 {
	static void prime_num(int n) {
		if (n < 2) {
			return;
		}
		if (n == 2) {
			System.out.println(n);
			return;
		} 
		for (int i=2; i<n; i++) {
			if (n % i == 0) {
				return;
			}
		}
		System.out.println(n);
		return;
	}

	
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        int num = sc.nextInt();
        
        for (int i=0; i<=num; i++) {
        	prime_num(i);
        }

				sc.close();
    }
}