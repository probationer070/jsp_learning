package hello;

import java.util.Scanner;

public class arr_test5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        String arr2[] = new String[num];
        
        for (int i=0; i<num; i++) {
            arr2[i] = sc.next();
        }
        sc.close();
        for (int i=0; i<num; i++) {
            String arr[] = arr2[i].split("");
            System.out.println(arr[0]+arr[arr.length-1]);
        }
	}
}
