package hello;

public class HelloJava {
	/*
	 주석 
	 public 접근제한자
	 class 이 파일은 클래스라고 알려주는 것
	 HelloJava 클래스 이름
	 * */
	public static void main(String[] args) {
		/*
		 * static 정적
		 * void 반환값 없음
		 * main 메소드(유사어: 함수) -- 특수 메소드
		 * 메소드는 기능에 역할을 함
		 * */
		
		//화면 하단 출력
		System.out.println("Hello Java");
	}

}
