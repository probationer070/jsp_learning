package hello;

import java.util.Scanner;

public class test03 {
	static int diff(char a, char b) {
		if (a > b) {
			return a - b;
		} else {
			return b - a;
		}
	}
	
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        char ch1, ch2;
        
        System.out.println("1st Char : ");
        ch1 = (sc.nextLine()).charAt(0);
        System.out.println("2st Char : ");
        ch2 = (sc.nextLine()).charAt(0);
        
        System.out.println(diff(ch1, ch2));

        sc.close();
    }
}