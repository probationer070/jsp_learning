package hello;

import java.io.*;
import java.util.StringTokenizer;

public class arr_test3{
    public static void main(String[] args) throws IOException {
        
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
        
        int len = Integer.parseInt(br.readLine());
        int cnt = 0;
        int[] nums = new int[len];
        
        StringTokenizer st = new StringTokenizer(br.readLine());
        
        for (int i=0; i < len; i++) {
            nums[i] = Integer.parseInt(st.nextToken());
        }
        int find = Integer.parseInt(br.readLine());
        
        for (int j=0; j < nums.length; j++) {
            if (nums[j] == find) {
                cnt++;
            }
        }
        System.out.println(cnt);
        
        br.close();
        bw.flush();
        bw.close();
    }
}
