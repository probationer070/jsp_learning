package hello;

import java.util.Arrays;
import java.util.Scanner;

public class arr_test4 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int len = sc.nextInt(); // 3 입력

		double arr[] = new double[len];
		
		for(int i=0; i<len; i++) {
			arr[i] = sc.nextDouble();
		}
		sc.close();
		
		double sum = 0;
		Arrays.sort(arr);
		
		for (int i=0; i < len; i++) {
			sum += (arr[i]/arr[len-1]) * 100;
		}
		System.out.println(sum / len);
	}
}

// 시험 횟수
// 과목별 점수
// 뉴=과목별 점수/max *100
// 결과물= 뉴들의 합/3
