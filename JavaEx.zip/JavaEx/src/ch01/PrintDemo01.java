package ch01;

public class PrintDemo01 {
	public static void main(String[] args) {
		int i = 97;			// 정수형 변수 i를 선언하고 97을 저장해라
		String str1 = "Java";	// 문자열 변수 str을 선언하고 Java라는 문자열을 저장해라
		double d = 3.14159f;	// 배정도 실수형(8byte) d를 선언하고 단정도(4byte) 실수값을 저장해라
		
//		System.out.println();	// 표준출력을 하고 한줄 내려라
		/*
		 포멧출력
		 str1에는 출력할 대상의 형식을 지
		 
		 */
		System.out.printf("정수 : %d ,실수 : %f\n",i,d); // 정수와 실수
		System.out.printf("8진수 : %o\n", i); // 8진수
		System.out.printf("16진수 : %x\n", i); // 16진수
		System.out.printf("문자 : %c\n", i); // 뮨자
		System.out.printf("5칸에 출력하면 : %5d\n", i);
		System.out.printf("5칸에 출력하면 : %05d\n", i);
		
		System.out.printf("문자열 : %s\n",str1); // 문자열
		System.out.printf("문자열(왼쪽 정렬) : %-10s\n",str1); // 문자열
		System.out.printf("실수출력 : %f\n", d);
		System.out.printf("실수출력(4칸출력,소수점2자리까지만) : %4.2f\n", d);
		System.out.printf("지수출력 : %e\n", d);
		System.out.printf("지수출력 : %e\n", 31.415);
		System.out.printf("실수출력(4칸출력,소수점1자리까지만) : %04.1f\n", d);
		System.out.printf("실수출력(4칸출력,소수점1자리까지만,왼쪽정렬) : %-4.1f\n", d);

	}
}
