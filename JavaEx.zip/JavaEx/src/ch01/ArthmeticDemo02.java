package ch01;


public class ArthmeticDemo02 {  
	public static void main(String[] args) {
		int a=1;
		int b=1;
		
		a++;
		++b;
		System.out.println(a);
		System.out.println(b);
		
		System.out.println("a++==>"+ a++);// 2 a를 출력하고 a증가
		System.out.println("++b==>"+ ++b); //3 b증가하고 출력해서 3
		System.out.println("a의 결과: "+a);//3 a값 출력이므로 증가한 3이 출력
		int r1, r2;
		
		r1=a++; // r1=a 넣고 a++해서 증가
		r2=++b; // ++b를(4) 먼저 하고 r2=b를 넣어라
		System.out.println("r1=a++ ==> "+r1); //3, a를 출력한다면 4
		System.out.println("r2=++b==>"+r2);//4
		
		//a+=2;
		a+=2; //== a++
		System.out.println(a);
		
		System.out.println(a!=2);
		
		// boolean r3 = a!=2;
		/* 논리 연산: 서로 다른 피연산자의 비교 연산을 하거나 참 거짓을 갖고있는 피연산자를
		              연산하면 그 결과 논리값으로 나온다.
		       
		 */
		
		
	}

}
