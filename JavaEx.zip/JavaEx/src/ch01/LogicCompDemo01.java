package ch01;

public class LogicCompDemo01 {

	public static void main(String[] args) {
		boolean a;
		boolean b;
		
		// JAVA에서는 앞에가 참이면 뒤는 보지도 않고 참
		
		a=false;
		b=false;
		
		System.out.printf("a = %b, b = %b\n", a, b);
		System.out.printf("a&&b : %b\n", a&&b);
		System.out.printf("a||b : %b\n", a||b);
		System.out.printf("a^b : %b\n", a^b);
		System.out.printf("!a : %b\n", !a);
		System.out.println("-----------------");
		
		a=false;
		b=true;
		
		System.out.printf("a = %b, b = %b\n", a, b);
		System.out.printf("a&&b : %b\n", a&&b);
		System.out.printf("a||b : %b\n", a||b);
		System.out.printf("a^b : %b\n", a^b);
		System.out.printf("!a : %b\n", !a);
		System.out.println("-----------------");
		
		a=true;
		b=false;
		
		System.out.printf("a = %b, b = %b\n", a, b);
		System.out.printf("a&&b : %b\n", a&&b);
		System.out.printf("a||b : %b\n", a||b);
		System.out.printf("a^b : %b\n", a^b);
		System.out.printf("!a : %b\n", !a);
		System.out.println("-----------------");
		
		a=true;
		b=true;
		
		System.out.printf("a = %b, b = %b\n", a, b);
		System.out.printf("a&&b : %b\n", a&&b);
		System.out.printf("a||b : %b\n", a||b);
		System.out.printf("a^b : %b\n", a^b);
		System.out.printf("!a : %b\n", !a);
		System.out.println("-----------------");
		
		
		
	}

}
