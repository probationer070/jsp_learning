package ch01;

public class AllocationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int value = 1;
		value += 1;
		System.out.println("깂 = " + value);
		value -= 1;
		System.out.println("깂 = " + value);
		value <<= 3;
		System.out.println("깂 = " + value);		
		value %= 3;
		System.out.println("깂 = " + value);
	}

}
