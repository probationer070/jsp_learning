package ch01;

public class ArithmeticDemo02 {
	public static void main(String[] args) {
		int a=1;
		int b=1;
		
		a++;                                           
		++b;                                           
		
		System.out.printf("a: %d\n", a);
		System.out.printf("b: %d\n", b);
		
		System.out.println("--------------------------");
		
		System.out.printf("a: %d\n", a++);
		System.out.printf("b: %d\n", ++b);
		System.out.println("a: "+a);

		System.out.println("--------------------------");
		
		int r1, r2;
		
		r1 = a++;
		r2 = ++b;
		
		System.out.println("r1: "+r1);
		System.out.println("r2: "+r2);
		
		a+=2;
		System.out.printf("a: %d\n", a);
		System.out.printf("a: %d\n", a!=2);
		
		System.out.println("--------------------------");
		
		// boolean r3 = a!=2;
		
		
	}
}
