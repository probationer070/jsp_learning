package ch01;

import java.util.*;
import java.io.*;

public class ScannerDemo01 {
	public static void main(String[] args) throws IOException {
		/*
		 1. import java.util.Scanner; 입력
		 2. main 메소드 안에서 
		 	Scanner sc = new Scanner(System.in); 입력
		 3. int x = sc.nextInt(); 입력
		 
		 */
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("숫자를 입력하시오 : ");
		int x = sc.nextInt();
		System.out.printf("입력받은 수 : %d\n",x);
		
		System.out.println("문자를 입력하시오 : ");
		String s = sc.next();
		System.out.printf("입력받은 문자 : %s\n",s);
		
		System.out.println("Byte를 입력하시오 : ");
		byte il = sc.nextByte();
		System.out.printf("입력받은 수(Byte) : %d\n",il);
		
		System.out.println("숫자(float)를 입력하시오 : ");
		Double d1 = sc.nextDouble();
		System.out.printf("입력받은 수(실수) : %f\n",d1);
		
		System.out.println("문자(줄바꿈)를 입력하시오 : ");
//		sc.nextLine();
		String s2 = sc.nextLine();
		System.out.printf("입력받은 문자(줄바꿈) : %s\n",s2);
		
		sc.close();
		// ------------------------------------------------------
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(System.out));
		
		System.out.println("[+] 숫자를 입력하시오 : ");
		int num = Integer.parseInt(br.readLine());
		bw.write("[-] : "+num+"\n");
		
		System.out.println("숫자를 입력하시오 : ");
		StringTokenizer st = new StringTokenizer(br.readLine());
		bw.write("입력값 : "+Integer.parseInt(st.nextToken()));
		
		br.close();
		bw.flush();
		bw.close();
		
	}
}
