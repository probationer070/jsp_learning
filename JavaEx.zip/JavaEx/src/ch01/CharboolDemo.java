package ch01;

public class CharboolDemo {

	public static void main(String[] args) {
		char ga1='가';
		char ga2='\uac00'; // unicode 가
		
		boolean cham = true;
		boolean geogit = false;
		
		System.out.println(ga1);
		System.out.println((int)ga1); // 가의 정수값
		System.out.println(ga2);		// 유니코드 값 출력, 가
//		System.out.println(++ga2);		// 유니코드 값 1 증가 
		System.out.println((int)++ga2);		// 유니코드 값 1 증가 
		System.out.println(ga2);		// 유니코드 값 출력, 각
		System.out.println(cham+"이(가) 아니면 "+geogit+" 입니다.");
	}

}
