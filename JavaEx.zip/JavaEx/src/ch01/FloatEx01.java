package ch01;

public class FloatEx01 {
	public static void main(String[] args) {
		// 실수 연습
		double d1 = 2345.235; 	// 8byte
		double d2 = 2345.235;	// 50 * 10 -2승
		float f1 = -245.223f;	// f도 가능
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(f1);
	}
}
