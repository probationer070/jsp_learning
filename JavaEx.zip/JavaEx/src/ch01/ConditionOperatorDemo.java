package ch01;

public class ConditionOperatorDemo {
	public static void main(String[] args) {
		int x=1;
		int y;
		
		y=(x==1) ? 10 : 20;
		System.out.println(y);
		System.out.println("-------------------------");
		
		
		y=(x>1) ? x++ : x+20;
		System.out.println(x);
		System.out.println(y);
	}
}
