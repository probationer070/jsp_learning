package ch01;

public class ArlthmeticEx2 {

	public static void main(String[] args) {
		//설명을 넣으면서 숫자를 찍어보기 
        System.out.println("덧셈결과: "+(1234+2345));
        System.out.println("뺄셈결과: "+(1234-2345));
        System.out.println("곱셈결과: "+(1234*2345));
        System.out.println("나눗셈결과: "+(1234/2345));
        System.out.println("나머지결과: "+(1234%2345));
	}

}
