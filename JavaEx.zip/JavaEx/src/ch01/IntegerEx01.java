package ch01;


public class IntegerEx01 {
	public static void main(String[] args) {
		byte a = 12;	// 1byte max:127
		short b = 260;	// 2byte
		char c = 65;		// str type
		int d = 123412;		// 4byte
		long e = 22525223;	// 8byte
		
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
		System.out.println(d);
		System.out.println(e);
		
		a=(byte)128; //큰 수를 작은 방에 넣으려면, 캐스팅 해야함.
		System.out.println("a="+a);
		b=a; // 자동 캐스팅 됨. b의 자료형이 크기가 더 크므로
		System.out.println("b="+b);
		b=(short) c; // 같은 크기ㅣ라도 캐스팅 필요, c가 문자형이기때문
		System.out.println("캐스팅 후="+b);
		d=c; //  큰 방에 c는 바로 들어감, 작은 타입 변수가 큰 타입 변수로 저장되는 경우 자동 캐스팅
		System.out.println(d);
		// 같은 값이라도 타입이 변경되었었다면 다시작은 타입으로 들어가기 위해 캐스팅 필요
		c = (char) d;
		System.out.println(c);
		
		c='가'; //char형은 값을 ''안에 한글자만 저장 가능
		System.out.println(c);
	}
}
