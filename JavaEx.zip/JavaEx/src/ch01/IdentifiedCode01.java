package ch01;

public class IdentifiedCode01 {
	public static void main(String[] args) {
		/* 식별자 - 클래스 이름, 메소드명, 변수명
        식별자는 문자,숫자, _, $만을 이용해서 만들 수 있다. 대소문자 구별한다. 시작은 문자로
        식별자로 자바 키워드는 사용할 수 없다.
        길이는 제한이 없다.(업무명을 기반으로 식별자 이름을 부여)
        
        변수 - 값이 변하도록 들어갈 수 있는 기억장소의 이름
            - 값을 저장할 수 있는 식별자 
        변수를 선언하는 방법
         1) 데이터타입 변수명(식별자);
            변수명(식별자) = 초깃값;
         2) 데이터타입 변수명(식별자) = 초깃값;
         
        데이터 타입은 크게 기초타입과 참조타입으로 구분하고
          기초타입은 - 정수타입(문자타입), 실수타입, 논리타입
                  - 정수타입: 공간의 크기 순으로 byte(1), short(char)(2), int(4*), long(8)
                  - 실수타입: float(4), double(8*)
                  - *붙어있는 타입이 기본타입
                  - 논리타입: boolean - true, false 두 개 값만 가질 수 있다.
      */ 
		
		
		
		// 1) 방식으로 변수 선언과 값 저장
		int var1;
		var1 = 1234;
		
		// 2) 방식으로 변수 선언과 값 저장
		int var2 = 2345;
		
		System.out.println(var1+var2);
		System.out.println(var1-var2);
		System.out.println(var1*var2);
		System.out.println(var1/var2);
		System.out.println(var1%var2);
		
		System.out.println("---------------------");
		
		var1 = 50; 
		var2 = 10;
		
		System.out.println(var1+var2);
		System.out.println(var1-var2);
		System.out.println(var1*var2);
		System.out.println(var1/var2);
		System.out.println(var1%var2);
		
		System.out.println("---------------------");

		var2 = var1; //var2라는 변수에 var1에 들어 있는 값을 복사해라
		
		//문자열을 저장하는 타입 : String
		//1) 방식
		String str1;
		str1 = "안녕";
		
		//2) 방식
		String str2 = "반가워";
		
		System.out.println(str1);
		System.out.println(str2);
		System.out.println(str1+str2);
		
		str1 = "Hello";
		str2 = "Java";
		
		System.out.println(str1+str2);
		
	}
}
