package ch01;

public class NumberTypeDemo {

	public static void main(String[] args) {
		int mach;
		int distance;
		mach = 340;
		distance = mach * 60 * 60;
		System.out.println("Distance, at sound speed for 1h : "+distance+"m");
		
		double radius;
		double area;
		
		radius = 10.0;
		area = radius * radius * 3.14;
		System.out.println("radius "+radius+" circle area : "+area);
		
		area = distance;
		System.out.println(area);
		
		distance = (int)area;
		System.out.println(distance);
		System.out.println((double)25/2);
		
		int a = (int)(10+25.8);
		System.out.println(a);
		
		double b = 10 + 25.8;
		System.out.println(b);
		
		
	}	

}
