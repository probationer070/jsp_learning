package ch01;

public class ArithmeticEx01 {

		static int num1, num2;
		
		public void plus(int num1, int num2) {
			System.out.println(num1 + num2);
		}
		
		public void sub(int num1, int num2) {
			System.out.println(num1 - num2);
		}
		
		public void multi(int num1, int num2) {
			System.out.println(num1 * num2);
		}
		
		public void quoti(int num1, int num2) {
			System.out.println(num1 / num2);
		}
		
		public void remain(int num1, int num2) {
			System.out.println(num1 % num2);
		}
		
	
		public static void main(String[] args) {
			int num1=50, num2=20;
			ArithmeticEx01 calc = new ArithmeticEx01();
			
		//		System.out.printf("%d \n", num1 * num2);
		//		System.out.printf("%d \n", num1 + num2);
		//		System.out.printf("%d \n", num1 / num2);
		//		System.out.printf("%d \n", num1 - num2);
		//		System.out.printf("%d \n", num1 % num2);
		//		System.out.println("-------------------");
			
			calc.plus(num1, num2);
			calc.sub(num1, num2);
			calc.multi(num1, num2);
			calc.quoti(num1, num2);
			calc.remain(num1, num2);
		}

}
