package ch01;

public class LogicCompDemo02 {

	public static void main(String[] args) {
		
		int x=0, y=1;
		boolean r = x<1 || y--<1;
		
		System.out.println(r);
		System.out.println("x="+x+", y="+y);
		System.out.println("-----------------");
		
		System.out.println((x<1)|(y--<1)); // 비트연산은 좌우 모두 연산함.
		System.out.println("x="+x+", y="+y);
		
		
	}

}
