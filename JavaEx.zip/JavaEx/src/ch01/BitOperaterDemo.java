package ch01;

public class BitOperaterDemo {
	public static void main(String[] args) {
		int i1 = -10;
		int i2 = i1 >> 1;	// i1 * (/2)*1
		int i3 = i1 >>> 1;	// 논리 시프트
		
		System.out.println(i1);
		System.out.println(i2);
		System.out.println(i3); // 빈공간에 0으로 채움
		
		System.out.printf("%x\n", 0b0101 & 0b0011); 
		System.out.printf("%x\n", 0b0101 | 0b0011); 
		System.out.printf("%x\n", 0b0101 ^ 0b0011); 
		
		
	}
}
