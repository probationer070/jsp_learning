package ch01;

public class OperatorPrecedenceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=5;
		int y=10;
		
		int z = ++x * --y;
		System.out.printf("%d\t %d\t %d\n", x, y, z);
		
		int k = ++x * y--;
		System.out.printf("%d\t %d\t %d\n", x, y, k);
		
		int year = 2024;
		
		System.out.println(year%4==0 && year%100!= 0 || year%400==0); 
		// NOT > AND > OR 순으로 우선순위가 빠름
	}

}
