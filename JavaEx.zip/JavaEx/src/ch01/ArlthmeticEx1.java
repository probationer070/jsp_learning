package ch01;

public class ArlthmeticEx1 {

	public static void main(String[] args) {
      // 산술연산 덧셈(+), 뺄셈(-), 곱셈(*), 나눗셈(/), 나머지(%)
		//자바는 명령이 끝나면 반드시 ;을 찍어야 함
		System.out.println(2354+1234);
		System.out.println(2354-1234);
		System.out.println(2354*1234);
		System.out.println(2354/1234); //나눗셈은 몫만 나옴
		System.out.println(2354%1234);
		
	}

}
