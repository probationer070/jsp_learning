package ch01;

public class BooleanEx01 {

	public static void main(String[] args) {
		boolean b = true;
		boolean c = false;
		
		System.out.println(b);
		System.out.println(c);
		
		int a1 = 20;
		int a2 = 20;
		System.out.println(a1==a2);
		System.out.println(a1>a2);
		System.out.println(a1<a2);
		System.out.println(a1>=a2);
		System.out.println(a1<=a2);
		System.out.println("------------------------------");
		System.out.println(1.1+0.1==1.2);
		System.out.println(0.5+0.7==1.1);
		
		System.out.println("------------------------------");

		
		b = a1 == a2;
		c = a1 < a2;
		System.out.println(b);
		System.out.println(c);

		
	}

}
