package ch01;

import java.util.Scanner;

public class ArithmeticDemo01 {
	public static void main(String[] args) {
		/* 
		 연산자는 피연산이 되는 값들을 원하는 처리방식으로 계산하는 것
		 JVM은 정수형은 4byte. 실수형은 8byte
		 
		 byte b1 = 10;
		 byte b2 = 20;
		 byte b3 = b1 + b2; 	// error !!!
		 
		 -> 계산결과가 4byte 여서 저장 불가능
		 
		 연산자
		 1. 증감연산자 : ++, --
		 2. 산술연산자 : +, -, * ,/, %
		 3. 시프트 연산자 : 비트단위로 이동하는 연산자
		 	<< : **2 곱함
		 	>> : **2 나눔
		 4. 부호연산자 : +, - (+10 , -10)
		 5. 비교연산자 : >, <. <=, >=, !=, instanceof(객체비교)
		 6. 비트 연산자 : &(AND), |(OR), ~(NOT), ^(XOR)
		 7. 논리 연산자 : &&(AND), ||(OR), ~(NOT), ^(XOR : 서로 같지 않을 때 참)
		 8. 조건 연산자 : [수식] ? A : B;
		  	수식 조건에 맞을 경우 : A 반환;
		  	수식 조건에 맞지 않을 경우 : B 반환;
		 9. 대입 연산자 : 왼쪽에 있는 변수에 오른쪽의 값, 결과를 저장함
		 	(1) int sum = 25 + 3; > 28 저장
		 	(2) 대입 연산자 쌍 : +=, *=, /=, ...
		 		두 항을 앞에 있는 연산자로 계산하고 왼쪽에 있는 변수에 결과를 저장
		 		sum += 1 > sum = sum + 1 과 같음
		 
		   */
		
		int a = 5;
		int b = 3;
		
		int res1;
		int res2;
		
		res1 = ++a;	// 모든 연산 중에 우선 선위가 가장 높음
		res2 = --b;	// 모든 연산 중에 우선 선위가 가장 높음
		
		System.out.printf("a : %d, b : %d\n", a, b);
		System.out.printf("res1 : %d, res2 : %d\n", res1, res2);
		
		res1 = a++; // 모든 연산 중에 우선 선위가 가장 낮음
		res2 = b--; // 모든 연산 중에 우선 선위가 가장 낮음
		
		System.out.printf("a : %d, b : %d\n", a, b);
		System.out.printf("res1 : %d, res2 : %d\n", res1, res2);
		
		res1 = a<<b; // a 값 b만큼 왼쪽으로 이동 > 7 * 2**1
		res2 = b>>a; // b 값 a만큼 오른쪽으로 이동 > 1 / 2**7
		
		System.out.printf("a : %d, b : %d\n", a, b);
		System.out.printf("res1 : %d, res2 : %d\n", res1, res2);
		
		System.out.println("---------------------------------");
		
		Scanner sc = new Scanner(System.in);
		int x = sc.nextInt();
		String r = (a > x) ? "크다" : "아니다";
		System.out.println(r);
		
		res1 += a;
		System.err.printf("res1 : %d, a : %d\n", res1, a);
		                                               
		res1 -= a;                                     
		System.out.printf("res1 : %d, a : %d\n", res1, a);
		                                               
		res1 *= a;                                     
		System.out.printf("res1 : %d, a : %d\n", res1, a);
		                                               
		res1 /= a;                                     
		System.out.printf("res1 : %d, a : %d\n", res1, a);
		                                               
		res1 %= a;                                     
		System.out.printf("res1 : %d, a : %d\n", res1, a);

		sc.close();
	}
}
