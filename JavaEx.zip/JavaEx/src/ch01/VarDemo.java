package ch01;

public class VarDemo {

	public static void main(String[] args) {
		// var는 정해지지 않은 변수 타입으로 값이 저장되는 순간 해당 변수의 타입이 결정됨.
		// var d; (X)
		// d =20; (X)
		var a = 10; //java 10.x 버전부터 사용가능
		var b =24.0;
		var c = "한국";
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}

}
