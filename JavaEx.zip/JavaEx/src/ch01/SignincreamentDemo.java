package ch01;

public class SignincreamentDemo {

	public static void main(String[] args) {
		int plusOne =1;
		int minusOne = -plusOne; // 부호 연산자
		
		System.out.println(plusOne);
		System.out.println(minusOne);
		System.out.println("-----------------------");
		
		int x=1, y=1;
		System.out.printf("x= %d, ++X= %d, x++= %d\n",x ,++x ,x++);
		System.out.printf("y= %d, ++y= %d, y++= %d\n",y ,++y ,y++);
		System.out.printf("x= %d, y= %d\n", x, y);
	}

}
