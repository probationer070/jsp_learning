package ch01;

public class ArithmeticEx02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("덧셈결과 : "+(1234+2345));
		System.out.println("뺄셈결과 : "+(1234-2345));
		System.out.println("곱셈결과 : "+(1234*2345));
		System.out.println("나눗셈결과 : "+(1234/2345));
		System.out.println("나머지결과 : "+(1234%2345));
		
		System.out.println("결과 : "+15+25);
	}

}
