package ch06.sec02;

public class FieldInitValue {
	byte byteField;
	short shortField;
	int intField;
	long longField;
	
	boolean boolField;
	char charField;

	float flaotField;
	double doubleField;
	
	int[] arrField;
	String StringField;
}
