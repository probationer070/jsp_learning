package ch06.sec02;

public class Car {
	String comp = "hyeonDai";
	String model = "granduer";
	String color = "Black";
	int maxSpeed = 350;
	int speed;
}
