package ch06.sec05.exam01;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car("포르쉐");
		Car yourCar = new Car("코닉세그");
		
		myCar.run();
		yourCar.run();
		
	}
}
