package ch06.sec05.exam06;

public class Earth {
	static final double EARTH_RADIUS = 6400;
	static final double EARTH_AREA = EARTH_RADIUS * EARTH_RADIUS * 4 * Math.PI;
	
}
