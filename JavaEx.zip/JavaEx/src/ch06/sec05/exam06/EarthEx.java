package ch06.sec05.exam06;

public class EarthEx {
	public static void main(String[] args) {
		System.out.println(Earth.EARTH_RADIUS);
		System.out.println(Earth.EARTH_AREA);
	}
}
