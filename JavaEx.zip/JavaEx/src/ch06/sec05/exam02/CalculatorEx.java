package ch06.sec05.exam02;

public class CalculatorEx {
	public static void main(String[] args) {
		System.out.println(Calculator.pi);
		Calculator c1 = new Calculator();
		System.out.println(c1.pi(5.0));
	}
}
