package ch06.sec03;

public class CarExample {
	public static void main(String[] args) {
		Car myCar = new Car();
		System.out.println(myCar.color);
		System.out.println(myCar.cc);

	}
}
