package ch06.sec03;

public class Koream {
	
	String nation = "Korea";
	String name;
	String ssn;
	
	public Koream (String n, String s) {
		this.name = n;
		this.ssn = s;
	}
}
