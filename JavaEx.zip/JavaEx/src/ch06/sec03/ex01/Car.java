package ch06.sec03.ex01;

public enum Car {
	AURA("a"), HEUI("b"), JEOP("c");
	
	
	
	private String str;
	
	Car (String str) {
		this.str = str;
	}
	
	public String str(String str) {
		return str;
	}
}


