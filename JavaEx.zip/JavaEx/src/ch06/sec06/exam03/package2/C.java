package ch06.sec06.exam03.package2;

import ch06.sec06.exam03.package1.*;

public class C {
//	A a; // 접근불가
	B b;
}
