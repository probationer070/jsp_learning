package ch06.sec06.exam02.kumho;

public class Tire {

}
