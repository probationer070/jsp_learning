package ch06.sec06.exam02.mycompany;

import ch06.sec06.exam02.hankook.Snowtire;
import ch06.sec06.exam02.hyundai.BigWidthTire;
import ch06.sec06.exam02.kumho.Engine;

public class Car {
	Engine engine = new Engine();
	Snowtire tire1 = new Snowtire();
	BigWidthTire tire2 = new BigWidthTire();
	ch06.sec06.exam02.hankook.Tire tire3 = new ch06.sec06.exam02.hankook.Tire();
	ch06.sec06.exam02.kumho.Tire tire4 = new ch06.sec06.exam02.kumho.Tire();
	
}
