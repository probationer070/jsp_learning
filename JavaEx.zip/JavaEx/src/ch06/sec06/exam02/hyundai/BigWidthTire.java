package ch06.sec06.exam02.hyundai;

public class BigWidthTire {

}
