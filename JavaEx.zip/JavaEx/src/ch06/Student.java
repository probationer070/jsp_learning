package ch06;

public class Student {

}
