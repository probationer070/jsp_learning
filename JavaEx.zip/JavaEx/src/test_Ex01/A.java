package test_Ex01;

public interface A {
	void methodA();
}
