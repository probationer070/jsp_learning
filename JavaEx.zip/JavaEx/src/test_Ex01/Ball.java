package test_Ex01;

public class Ball {
	public double radius = 2.0;
	public double getVolume() {
		return  4/3 * 3.14 * radius * radius * radius;
	}
}
