package test_Ex01;

public interface Button {
	void click();
}
