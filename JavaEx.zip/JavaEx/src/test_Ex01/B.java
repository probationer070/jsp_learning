package test_Ex01;

public interface B {
	void methodB();
}
