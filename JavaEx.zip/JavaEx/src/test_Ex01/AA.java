package test_Ex01;

public interface AA {
	void method1 ();
	default void method2() {};
}
