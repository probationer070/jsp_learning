package test_Ex01;

public class Abc implements C {
	@Override
	public void methodA() {
		
	}
	@Override
	public void methodB() {
		
	}
	@Override
	public void methodC() {
		
	}
}
