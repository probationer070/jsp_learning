package test_Ex01;

public abstract class Birds {
	public abstract void fly();
}
