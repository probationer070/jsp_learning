package ch05.sec03;

public class NoneEnumDemo {
	public static void main(String[] args) {
		int i = 7;
		System.out.println("Java" + i);
		System.out.println("Java" + 7);
		System.out.println(1 + 7 + "Java" + 7 + 1);
	}
}
