package ch05;

public class ArrayDemo02 {
	public static void main(String[] args) {
		int su[] = {1,2,3,4,5,6}; 
	
		for (int i=0; i<6; i++) {
			System.out.println("su["+i+"]: "+su[i]);
		}
	}
}
