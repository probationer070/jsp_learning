package ch05;

public class create_account {
	
	public static void main(String[] args) {
		account account_A = new account();
		// account account_B = new account();
		
		account_A.admin = "user";
		account_A.remain = 100000000;
		// long remain;
	}
}
