package ch10.sec01.exam01;

public class ArrayIndexOutOfBoundsException {
	public static void main(String[] args) {
		String data1 = args[0];
		String data2 = args[1];
		
		System.out.println(data1);
		System.out.println(data2);
	}
}
