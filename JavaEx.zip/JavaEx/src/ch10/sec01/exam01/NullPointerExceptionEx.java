package ch10.sec01.exam01;

public class NullPointerExceptionEx {
	@SuppressWarnings("null")
	public static void main(String[] args) {
		String data = null;
		System.out.println(data.toString());
	}
}
