package ch17_12.sec01;

// import java.util.Random;
// import java.util.stream.IntStream;
// import java.util.stream.Stream;

public class Etc2StreamDemo {
  public static void main(String[] args) {
    // IntStream is1 = IntStream.iterate(1, x -> x + 2);
    // // is1.forEach(x -> System.out.print(x + " "));  // 무한 증가 2만큼
    
    // IntStream is2 = new Random().ints(0, 10);
    // // is2.forEach(x -> System.out.print(x + " ")); // 무한 랜덤값으로
    // Stream<Double> ds = Stream.generate(Math::random);

    // IntStream is3 = IntStream.range(1, 5);
  }
}
