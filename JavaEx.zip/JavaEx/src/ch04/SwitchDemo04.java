package ch04;

import java.util.Scanner;

public class SwitchDemo04 {

	public static void main(String[] args) {
		/*
		 kind에 입력되는 문자열의 종을 출력하고자 함.
		 { Tiger, Lion, Human, Eagle, sparrow, pigeoan, Fish, Tuna, Goldenfish, mold}
		 */
		
		
		String kind = "";
		Scanner sc = new Scanner(System.in);
		String bio = sc.next();
		
//		switch(bio) {
//		case "Tiger":
//		case "Lion":
//		case "Human":
//			kind="Mammalia";
//			break;
//		case "Eagle":
//		case "sparrow":
//		case "pigeoan":
//			kind="Bird";
//			break;
//		case "mackerel":
//		case "Tuna":
//		case "Goldenfish":
//			kind="Fish";
//			break;
//		case "mold":
//			kind="Fungi";
//			break;
//		default:
//			kind="WTF?";
//		}
		
//		System.out.printf("%s", kind);
		
		
		// JDK 14 이상만 가능
		switch(bio) {
		case "Tiger", "Lion", "Human" -> kind="Mammalia";
		case "Eagle", "sparrow", "pigeoan" -> kind="Bird";
		case "mackerel", "Tuna", "Goldenfish" -> kind="Fish";
		case "mold" -> kind="Fungi";
		default->kind="WTF?";
		}
		System.out.printf("%s", kind);
		sc.close();
	}
}
