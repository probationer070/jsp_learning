package ch04;

import java.util.Scanner;

public class MethodDemo04 {
	static void print_mine(String A) {
		System.out.println(A);
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("문자열 입 력 : ");
		
		String chars = sc.nextLine();
		sc.close();
		print_mine(chars);
	}
}
