package ch04;

import java.util.Scanner;

public class MethodDemo02 {
	static void echo(int num, String str) {
		int i = 0;
		while (i < num) {
			System.out.println(str);
			i++;
		}
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int num = sc.nextInt();
		String check = sc.next();
		
		echo(num, check);
		sc.close();
	}
}
