package ch04;

// import java.io.BufferedReader;
import java.io.IOException;
// import java.io.InputStreamReader;
import java.util.Scanner;

public class MethodDemo03 {
	static double Mean(int num[]) {
		int sum = 0;
		for (int i=0; i < num.length; i++) {
			sum += num[i];
		}
		double Means = sum / num.length;
		return Means;
	}
	
	public static void main(String[] args) throws IOException {
//		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		Scanner sc = new Scanner(System.in);
		System.out.println("과목 개수 : ");
//		
		int num = sc.nextInt();
		
//		int num = Integer.parseInt(br.readLine());
		
		int scores[] = new int[num];
		
		for (int i=0; i<num; i++) {
			System.out.printf("%d번째 과목 점수 : ", i+1);
			int score = sc.nextInt();
//			int score = Integer.parseInt(br.readLine());
			scores[i] = score;
		}
		sc.close();
		long beforeTime = System.currentTimeMillis();
		
		System.out.println(Mean(scores));
		long afterTime = System.currentTimeMillis(); 
		long secDiffTime = (afterTime - beforeTime)/1000;
		System.out.println("시간차이(ms) : "+secDiffTime);
	}
}
