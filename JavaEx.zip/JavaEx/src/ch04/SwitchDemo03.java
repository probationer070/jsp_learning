package ch04;

import java.util.Scanner;

public class SwitchDemo03 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String bio = sc.next();
		
		String kind = switch (bio) {
		case "Tiger", "Lion", "Human":
			yield "Mammalia";
		case "Eagle", "sparrow", "pigeoan":
			yield "Bird";
		case "mackerel", "Tuna", "Goldenfish":
			yield "Fish";
		case "mold": 
			yield "Fungi";
		default:
			yield "몰라";
		};
		
		sc.close();
		System.out.printf("%s", kind);
		// JDK 14 이상만 가능
//		switch(bio) {
//		case "Tiger", "Lion", "Human" -> kind="Mammalia";
//		case "Eagle", "sparrow", "pigeoan" -> kind="Bird";
//		case "mackerel", "Tuna", "Goldenfish" -> kind="Fish";
//		case "mold" -> kind="Fungi";
//		default->kind="WTF?";
//		}
//		System.out.printf("%s", kind);

	}
}
