package ch04;

public class MethodDemo01 {
	static int sum_ve(int a, int b) {
		int sum = 0;
		for (int i=a; i <= b; i++) {
			sum += i;
		}
		return sum;
	}
	
	public static void main(String[] args) {
		int a = 10;
		int b = 100;
		
		System.out.println(sum_ve(a,b));
		System.out.println(sum_ve(1,10));
	}
}
