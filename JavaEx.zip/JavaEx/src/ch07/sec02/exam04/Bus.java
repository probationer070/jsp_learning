package ch07.sec02.exam04;

public class Bus extends Vehicle {
	@Override
	public void run() {
		System.out.println("버스가 달린다.");
	}
}
