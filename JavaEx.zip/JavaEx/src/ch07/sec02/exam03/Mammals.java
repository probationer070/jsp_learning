package ch07.sec02.exam03;

public class Mammals extends Animal{
	public void sound() {
		System.out.println("I hear Something");
	}
}
