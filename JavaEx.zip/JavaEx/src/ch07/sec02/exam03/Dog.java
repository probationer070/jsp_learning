package ch07.sec02.exam03;

public class Dog extends Mammals{
	@Override
	public void sound() {
		System.out.println("Bark!");
	}
}
