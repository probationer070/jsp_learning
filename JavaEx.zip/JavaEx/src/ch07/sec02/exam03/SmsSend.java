package ch07.sec02.exam03;

public class SmsSend extends MsgSend {
	@Override
	public void send() {
		System.out.println("SMS Sended");
	}
}
