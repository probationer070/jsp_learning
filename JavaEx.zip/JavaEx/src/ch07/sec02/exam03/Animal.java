package ch07.sec02.exam03;

public class Animal {
	public void eat() {
//		System.out.println("Eat Something");
	}
	public void sleep() {
//		System.out.println("Sleeping...");
	}
	public void move() {
//		System.out.println("Acting");
	}
}
