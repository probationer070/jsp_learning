package ch07.sec02.exam03;

public class Cat extends Mammals{
	@Override
	public void sound() {
		System.out.println("Meow!");
	}
}
