package ch07.sec02.exam03;

public class EmailSend extends MsgSend {
	@Override
	public void send() {
		System.out.println("E-mail Sended");
	}
}
