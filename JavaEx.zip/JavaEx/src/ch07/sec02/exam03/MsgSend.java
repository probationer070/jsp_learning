package ch07.sec02.exam03;

public class MsgSend {
	public void send() {
		System.out.println("Message Sended");
	}
}
