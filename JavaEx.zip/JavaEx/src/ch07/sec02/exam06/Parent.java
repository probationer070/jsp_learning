package ch07.sec02.exam06;

public class Parent {

}
