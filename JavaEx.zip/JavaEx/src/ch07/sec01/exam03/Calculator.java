package ch07.sec01.exam03;

public class Calculator {
	double areaCircle(double r) {
		System.out.println("Calculator.areaCircle()");
		return r * r * 3.14159;
	}
}
