package ch07.sec01.exam07.pak2;

import ch07.sec01.exam07.pak1.A;

public class C {	
	protected void method() {
//		A a = new A();			// 접근 불가
//		a.field = "value";
//		a.method();
	}
}
