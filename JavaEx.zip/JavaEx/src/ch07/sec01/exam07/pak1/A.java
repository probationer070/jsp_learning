package ch07.sec01.exam07.pak1;

public class A {
	protected String field;
	
	protected A() {
		
	}
	
	protected void method() {
		
	}
}
