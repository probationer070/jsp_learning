package ch07.sec01.exam07.pak1;

public class B {	
	protected void method() {
		A a = new A();
		a.field = "value";
		a.method();
	}
}
