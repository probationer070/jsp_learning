package ch07.sec01.exam04.other;

import ch07.sec01.exam04.One;

public class Three extends One{
	void print() {
		One o = new One();
//		System.out.println(secret);
//		System.out.println(roommate);
//		System.out.println(o.child);
		System.out.println(o.anybody);
	}
}
