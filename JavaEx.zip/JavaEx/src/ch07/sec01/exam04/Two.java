package ch07.sec01.exam04;

public class Two {
	void print() {
		One o = new One(); // has a 관계
//		System.out.println(o.secret);
		System.out.println(o.roommate);
		System.out.println(o.child);
		System.out.println(o.anybody);
	}
}
