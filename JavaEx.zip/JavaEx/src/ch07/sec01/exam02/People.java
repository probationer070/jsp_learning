package ch07.sec01.exam02;

public class People {
	public String name;
	public String ssn;

	
}
