package ch07.sec01.exam05;

//public class VeryImportantPerson extends Members{
//}
