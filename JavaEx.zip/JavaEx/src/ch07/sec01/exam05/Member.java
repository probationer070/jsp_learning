package ch07.sec01.exam05;

public final class Member {
}
