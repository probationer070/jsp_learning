package ch07.sec03.exam01;

public class Smartphone extends Phone {
	public Smartphone(String owner) {
		super(owner);
	}
	
	public void internetSearch() {
		System.out.println("Start Searching in Internet");
	}
}
