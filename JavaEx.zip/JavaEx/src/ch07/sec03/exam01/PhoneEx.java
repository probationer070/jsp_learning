package ch07.sec03.exam01;

public class PhoneEx {
	public static void main(String[] args) {
		Smartphone myphone = new Smartphone("김민서");
		
		myphone.turnOn();
		myphone.internetSearch();
		myphone.turnoff();
	}
}
