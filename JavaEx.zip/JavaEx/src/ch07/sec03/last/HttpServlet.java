package ch07.sec03.last;

public abstract class HttpServlet {
	public abstract void service();
}
