package ch04.com.dao;

public class Calculator {
	public int process(int n) {
		return n * n * n;
	}
}
