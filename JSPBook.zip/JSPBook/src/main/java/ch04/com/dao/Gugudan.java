package ch04.com.dao;

public class Gugudan {
	public int process(int i) {
		int n = 5;
		return n * i;
	}
}
