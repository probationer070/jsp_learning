package ch04.com.dao;

public class Person {
	private String id = "20240417";
	private String name="박재환";
	
	public Person() {}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
