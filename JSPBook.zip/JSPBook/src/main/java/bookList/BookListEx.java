package bookList;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookListEx {
	
	Connection conn;
	
	public BookListEx() {
		String url = "jdbc:oracle:thin:@localhost:1521:xe";
		String user = "madang";
		String password = "madang";
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("드라이버 로드 성공");
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			conn = DriverManager.getConnection(url, user, password);
			System.out.println("데이터베이스 연결 성공");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private void sqlRun() {
		String query = "SELECT * FROM Book";
		ResultSet rs = null;
		PreparedStatement pstmt = null;
		try {			
			pstmt = conn.prepareStatement(query);	// 그냥 statement 는 보안에 취약
			rs = pstmt.executeQuery();
			System.out.println("Book NO \t BOOK NAME \t\t PUBLISHER \t PRICE");
			while(rs.next()) {
				System.out.print("\t"+rs.getInt(1));
				System.out.print("\t"+rs.getString(2));
				System.out.print("\t\t"+rs.getString(3));
				System.out.println("\t"+rs.getInt(4));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if(rs != null) try{rs.close();} catch (SQLException e) {}
			if(pstmt != null) try{pstmt.close();} catch (SQLException e) {}
			if(conn != null) try{conn.close();} catch (SQLException e) {}
		}
	}
	
	public static void main(String[] args) {
		BookListEx so = new BookListEx();
		so.sqlRun();
	}
}
