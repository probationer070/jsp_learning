package com.ecom6.common.vo;

public class PageInfo {
	public static final int ROW_OF_PAGE = 6;
	public static final int PAGE_OF_BLOCK = 3;	
}
